# spectagram-stage-1
project solution for c81
